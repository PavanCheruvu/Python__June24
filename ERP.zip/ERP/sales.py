def f1():
	print("sales code:123")