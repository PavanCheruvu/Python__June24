def display():
	print("List of customer records")