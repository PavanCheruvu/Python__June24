def fx():
	print('Enquiry details')