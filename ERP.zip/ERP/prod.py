def f2():
	print("product details")