def f3():
	return 1245.32